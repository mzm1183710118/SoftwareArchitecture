# MQ
java SpringBoot实现简单的MQ
