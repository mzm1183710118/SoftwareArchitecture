# GWARBMS
General wholesale and retail business management system 

通用批发零售业务管理系统

基于Spring Boot开发，前端使用LayUI框架

启动项目需要开启数据库服务，开启redis服务

## Authors

[Jian Xu](https://github.com/BeiyanLuansheng), [Zhimin Mei](https://github.com/mzm1183710118), [Qian Xu](https://github.com/xuqianxuqian), [Jiajia Dai](https://github.com/1183710121djj), [Peisen Li](https://github.com/1183710108), [Zhuoning Guo](https://github.com/gzn00417)

