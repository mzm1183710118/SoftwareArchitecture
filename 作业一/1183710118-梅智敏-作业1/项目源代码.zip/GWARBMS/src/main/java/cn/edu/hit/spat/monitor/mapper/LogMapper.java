package cn.edu.hit.spat.monitor.mapper;

import cn.edu.hit.spat.monitor.entity.SystemLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author MrBird
 */
public interface LogMapper extends BaseMapper<SystemLog> {

}
