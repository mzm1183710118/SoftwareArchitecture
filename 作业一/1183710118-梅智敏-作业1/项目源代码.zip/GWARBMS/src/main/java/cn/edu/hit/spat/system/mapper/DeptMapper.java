package cn.edu.hit.spat.system.mapper;

import cn.edu.hit.spat.system.entity.Dept;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author MrBird
 */
public interface DeptMapper extends BaseMapper<Dept> {
}
