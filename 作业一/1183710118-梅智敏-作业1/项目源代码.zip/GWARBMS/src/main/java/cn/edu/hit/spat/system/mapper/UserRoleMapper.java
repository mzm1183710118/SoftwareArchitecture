package cn.edu.hit.spat.system.mapper;

import cn.edu.hit.spat.system.entity.UserRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author MrBird
 */
public interface UserRoleMapper extends BaseMapper<UserRole> {

}
